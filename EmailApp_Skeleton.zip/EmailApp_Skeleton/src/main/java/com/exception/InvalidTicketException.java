package com.exception;

public class InvalidTicketException extends Exception {

	//generate default and one argument constructor

}
