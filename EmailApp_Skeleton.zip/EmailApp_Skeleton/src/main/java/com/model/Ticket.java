package com.model;

public class Ticket {
	
	int ticketId;
	String  ticketType;
	String customerName;
	String phone;
	String descriptionIssue;
	int slaHours;
	
	
	//write code for all argument constructor
	//write getter/setter methods
	//write to_string method
	

}
